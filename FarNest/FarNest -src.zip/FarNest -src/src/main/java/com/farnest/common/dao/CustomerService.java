package com.farnest.common.dao;

public interface CustomerService {

}
