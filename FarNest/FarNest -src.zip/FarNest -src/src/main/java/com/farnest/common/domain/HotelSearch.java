package com.farnest.common.domain;

import java.util.Date;

public class HotelSearch {
 private String CityAjaxH;
 private Date SDATEH;
 private Date EDATEH;
public String getCityAjaxH() {
	return CityAjaxH;
}
public void setCityAjaxH(String cityAjaxH) {
	CityAjaxH = cityAjaxH;
}
public Date getSDATEH() {
	return SDATEH;
}
public void setSDATEH(Date sDATEH) {
	SDATEH = sDATEH;
}
public Date getEDATEH() {
	return EDATEH;
}
public void setEDATEH(Date eDATEH) {
	EDATEH = eDATEH;
}
 
}
